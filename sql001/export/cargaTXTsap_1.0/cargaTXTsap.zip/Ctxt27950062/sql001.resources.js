﻿// Desktop Studio
// Auto-generated declaration file : do not modify !



var POPUPS = POPUPS || ctx.addApplication('POPUPS');



var SAPLogon760 = ctx.addApplication('SAPLogon760', {"nature":"UIAUTOMATION","path":"C:\\Program Files (x86)\\SAP\\FrontEnd\\SapGui\\saplogon.exe"});

SAPLogon760.pWindowSAPLogon76 = SAPLogon760.addPage('pWindowSAPLogon76', {"comment":"Window - SAP Logon 760"});
SAPLogon760.pWindowSAPLogon76.stARTHAQAS = SAPLogon760.pWindowSAPLogon76.addItem('stARTHAQAS');

SAPLogon760.pSAPLogin = SAPLogon760.addPage('pSAPLogin', {"comment":"GuiMainWindow - SAP","nature":"SAPGUI","customType":"GuiMainWindow"});
SAPLogon760.pSAPLogin.edMandante = SAPLogon760.pSAPLogin.addItem('edMandante', {"customType":"GuiTextField"});
SAPLogon760.pSAPLogin.edUsuarios = SAPLogon760.pSAPLogin.addItem('edUsuarios', {"customType":"GuiTextField"});
SAPLogon760.pSAPLogin.oClvAcc = SAPLogon760.pSAPLogin.addItem('oClvAcc', {"customType":"GuiPasswordField"});
SAPLogon760.pSAPLogin.edIdioma = SAPLogon760.pSAPLogin.addItem('edIdioma', {"customType":"GuiTextField"});

SAPLogon760.pSAPEasyAccess = SAPLogon760.addPage('pSAPEasyAccess', {"comment":"GuiMainWindow - SAP Easy Access","nature":"SAPGUI","customType":"GuiMainWindow"});
SAPLogon760.pSAPEasyAccess.oGuiOkCodeField = SAPLogon760.pSAPEasyAccess.addItem('oGuiOkCodeField', {"customType":"GuiOkCodeField"});
SAPLogon760.pSAPEasyAccess.btIFinalizar = SAPLogon760.pSAPEasyAccess.addItem('btIFinalizar', {"customType":"GuiButton"});

SAPLogon760.pVentasYFacturasMas = SAPLogon760.addPage('pVentasYFacturasMas', {"comment":"GuiMainWindow - Ventas y Facturas masiva","nature":"SAPGUI","customType":"GuiMainWindow"});
SAPLogon760.pVentasYFacturasMas.edFichero = SAPLogon760.pVentasYFacturasMas.addItem('edFichero', {"customType":"GuiCTextField"});
SAPLogon760.pVentasYFacturasMas.btEjecutar = SAPLogon760.pVentasYFacturasMas.addItem('btEjecutar', {"customType":"GuiButton"});
SAPLogon760.pVentasYFacturasMas.btIFinalizar = SAPLogon760.pVentasYFacturasMas.addItem('btIFinalizar', {"customType":"GuiButton"});

SAPLogon760.pPosMensajes = SAPLogon760.addPage('pPosMensajes', {"comment":"GuiModalWindow - Pos.docum.: Visualizar mensajes","nature":"SAPGUI","customType":"GuiModalWindow"});
SAPLogon760.pPosMensajes.oTip = SAPLogon760.pPosMensajes.addItem('oTip', {"occurs":1,"customType":"GuiLabel"});
SAPLogon760.pPosMensajes.btAceptar = SAPLogon760.pPosMensajes.addItem('btAceptar', {"customType":"GuiButton"});
SAPLogon760.pPosMensajes.btCancelar = SAPLogon760.pPosMensajes.addItem('btCancelar', {"customType":"GuiButton"});

SAPLogon760.pSalirDelSistema = SAPLogon760.addPage('pSalirDelSistema', {"comment":"GuiModalWindow - Salir del sistema","nature":"SAPGUI","customType":"GuiModalWindow"});
SAPLogon760.pSalirDelSistema.btSí = SAPLogon760.pSalirDelSistema.addItem('btSí', {"customType":"GuiButton"});


var MicrosoftExcelRep = ctx.addApplication('MicrosoftExcelRep', {"nature":"UIAUTOMATION","path":"C:\\Program Files (x86)\\Microsoft Office\\Office12\\EXCEL.EXE"});

MicrosoftExcelRep.pWindowMicrosoftEx = MicrosoftExcelRep.addPage('pWindowMicrosoftEx', {"comment":"Window - Microsoft Excel - ReporteENCO.xlsm"});
MicrosoftExcelRep.pWindowMicrosoftEx.btMacros = MicrosoftExcelRep.pWindowMicrosoftEx.addItem('btMacros');

MicrosoftExcelRep.pWindowMacro = MicrosoftExcelRep.addPage('pWindowMacro', {"comment":"Window - Macro"});
MicrosoftExcelRep.pWindowMacro.oCrearObjetoTabla = MicrosoftExcelRep.pWindowMacro.addItem('oCrearObjetoTabla');
MicrosoftExcelRep.pWindowMacro.oReporteConsolidado = MicrosoftExcelRep.pWindowMacro.addItem('oReporteConsolidado');
MicrosoftExcelRep.pWindowMacro.oReporteDetallado = MicrosoftExcelRep.pWindowMacro.addItem('oReporteDetallado');

MicrosoftExcelRep.pWindowReporteador = MicrosoftExcelRep.addPage('pWindowReporteador', {"comment":"Window - Reporteador"});
MicrosoftExcelRep.pWindowReporteador.btAceptar = MicrosoftExcelRep.pWindowReporteador.addItem('btAceptar');
MicrosoftExcelRep.pWindowReporteador.edEdit = MicrosoftExcelRep.pWindowReporteador.addItem('edEdit');
MicrosoftExcelRep.pWindowReporteador.edEdit1 = MicrosoftExcelRep.pWindowReporteador.addItem('edEdit1');

MicrosoftExcelRep.pWindowMicrosoftEx1 = MicrosoftExcelRep.addPage('pWindowMicrosoftEx1', {"comment":"Window - Microsoft Excel"});
MicrosoftExcelRep.pWindowMicrosoftEx1.btAceptar = MicrosoftExcelRep.pWindowMicrosoftEx1.addItem('btAceptar');

GLOBAL.events.START.on(function(ev) { 
    GLOBAL.createExtendedConnector(e.extendedConnector.UIAutomation, '', '', '');
});
