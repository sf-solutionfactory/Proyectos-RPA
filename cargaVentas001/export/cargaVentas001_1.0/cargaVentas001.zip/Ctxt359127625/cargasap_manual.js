﻿
// ----------------------------------------------------------------
//   Test menu for scenario carga_SAP_Manual 
// ----------------------------------------------------------------
GLOBAL.events.START.on(function (ev) {
	if (ctx.options.isDebug) {
		// Add item in systray menu.
		systray.addMenu('', 'carga_SAP_Manual', 'Test carga_SAP_Manual', '', function (ev) {
			var rootData = ctx.dataManagers.rootData.create();

			// Initialize your data here.
			GLOBAL.scenarios.carga_SAP_Manual.start(rootData);
		});
	}
});

//---------------------------------------------------
// Scenario carga_SAP_Manual Starter ()
//---------------------------------------------------

// ----------------------------------------------------------------
//   Scenario: carga_SAP_Manual
// ----------------------------------------------------------------
GLOBAL.scenario( {
	carga_SAP_Manual: function (ev, sc) {
		var rootData = sc.data;

		sc.setMode(e.scenario.mode.clearIfRunning);
		sc.setScenarioTimeout(12000000); // Default timeout for global scenario.
		sc.onError(function (sc, st, ex) {
			sc.endScenario();
		}); // Default error handler.
		sc.onTimeout(600000, function (sc, st) {
			sc.endScenario();
		}); // Default timeout handler for each step.
		sc.step(GLOBAL.steps.getSettingsM_1, GLOBAL.steps.getFilenameM_1);
		sc.step(GLOBAL.steps.getFilenameM_1, GLOBAL.steps.Read_txtM_1);
		sc.step(GLOBAL.steps.Read_txtM_1, GLOBAL.steps.setListM_1);
		sc.step(GLOBAL.steps.setListM_1, GLOBAL.steps.Write_txtM_1);
		sc.step(GLOBAL.steps.Write_txtM_1, GLOBAL.steps.Start_SAPLogon750);
		sc.step(GLOBAL.steps.Start_SAPLogon750, GLOBAL.steps.pWindowSAPLogon75_man);
		sc.step(GLOBAL.steps.pWindowSAPLogon75_man, GLOBAL.steps.Declare_credentialM);
		sc.step(GLOBAL.steps.Declare_credentialM, GLOBAL.steps.Get_credentialM);
		sc.step(GLOBAL.steps.Get_credentialM, GLOBAL.steps.pSAPLogin_management);
		sc.step(GLOBAL.steps.pSAPLogin_management, GLOBAL.steps.pSAPEasyAccess_manage);
		sc.step(GLOBAL.steps.pSAPEasyAccess_manage, GLOBAL.steps.Disable_step_timeout);
		sc.step(GLOBAL.steps.Disable_step_timeout, GLOBAL.steps.pVentasYFacturasMas_m);
		sc.step(GLOBAL.steps.pVentasYFacturasMas_m, GLOBAL.steps.pPosDocumVisualiza_ma);
		sc.step(GLOBAL.steps.pPosDocumVisualiza_ma, GLOBAL.steps.pVentasYFacturasMas_m_1);
		sc.step(GLOBAL.steps.pVentasYFacturasMas_m_1, GLOBAL.steps.pSAPEasyAccess_manage_1);
		sc.step(GLOBAL.steps.pSAPEasyAccess_manage_1, GLOBAL.steps.pSalirDelSistema_mana);
		sc.step(GLOBAL.steps.pSalirDelSistema_mana, GLOBAL.steps.deleteFileMM);
		sc.step(GLOBAL.steps.deleteFileMM, null);
	}
}, ctx.dataManagers.rootData).setId('bf1c73c4-710f-4aee-b105-6e37a74ac704');

// ----------------------------------------------------------------
//   Step: getSettingsM_1
// ----------------------------------------------------------------
GLOBAL.step( {
	getSettingsM_1: function (ev, sc, st) {
		var rootData = sc.data;
		// Declares a setting

		ctx.setting( {
			fechaInicio: {
				comment: "Fecha Inicio",
				server: true
			}
		});
		// Declares a setting

		ctx.setting( {
			fechaFin: {
				comment: "Fecha fin",
				server: true
			}
		});
		// Declares a setting

		ctx.setting( {
			soloCarga: {
				comment: "solo Carga",
				server: true
			}
		});
		// Declares a setting

		ctx.setting( {
			idCentro: {
				comment: "idCentro",
				server: true
			}
		});
		// Declares a setting

		ctx.setting( {
			tipoConsulta: {
				comment: "tipoConsulta",
				server: true
			}
		});
		// Retrieves the value of a setting

		ctx.settings.fechaInicio.get(function (code, label, setting) {
			if (code == e.error.OK) {
				// get value from setting.value
				rootData.Manual.fechaIni = setting.value;
				// Retrieves the value of a setting

				ctx.settings.fechaFin.get(function (code, label, setting) {
					if (code == e.error.OK) {
						// get value from setting.value
						rootData.Manual.fechaFin = setting.value;
						// Retrieves the value of a setting

						ctx.settings.soloCarga.get(function (code, label, setting) {
							if (code == e.error.OK) {
								// get value from setting.value
								rootData.Manual.soloCarga = setting.value;
								// Retrieves the value of a setting

								ctx.settings.idCentro.get(function (code, label, setting) {
									if (code == e.error.OK) {
										// get value from setting.value
										rootData.Manual.idCentro = setting.value;
										// Retrieves the value of a setting

										ctx.settings.tipoConsulta.get(function (code, label, setting) {
											if (code == e.error.OK) {
												// get value from setting.value
												rootData.tipoConsulta = setting.value;
												sc.endStep(); // getFilenameM_1
												return ;
											}
										});
									}
								});
							}
						});
					}
				});
			}
		});
	}
});

// ----------------------------------------------------------------
//   Step: getFilenameM
// ----------------------------------------------------------------
GLOBAL.step( {
	getFilenameM_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '22d97616-987a-461b-b8db-3b75b0d93778');
		// Get filename
		var date = new Date();
		var mes = date.getMonth() + 1;
		if (mes < 10) {
			mes = "0" + mes;
		}
		var dia = date.getDate() - 0;
		if (dia < 10) {
			dia = "0" + dia;
		}
		rootData.datetime = date.getFullYear().toString() + mes + dia;
		rootData.fechaActual = dia + "/" + mes + "/" + date.getFullYear();
		rootData.fechaActual = date.getFullYear() + mes + dia;
		rootData.filename = "C:\\LAYOUT\\in\\LayoutENCO" + rootData.datetime + "_MM.txt";
		rootData.filenameO = "C:\\LAYOUT\\out\\LayoutENCO" + rootData.datetime + "_MM.txt";
		//		ctx.fso.file.write(rootData.filename, "", e.file.encoding.UTF8);

		sc.endStep(); // Read_txtM_1
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: Read_txtM_1
// ----------------------------------------------------------------
GLOBAL.step( {
	Read_txtM_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'c5efa48b-eea0-40b4-86b7-423a21eafff6');
		// Leer archivo generado
		var file = rootData.filename;
		rootData.lines = ctx.fso.file.read(file, e.file.encoding.UTF8);
		sc.endStep(); // setListM_1
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: setListM_1
// ----------------------------------------------------------------
GLOBAL.step( {
	setListM_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '2bd908e6-f4ac-4339-9015-a107ea89eb91');
		// Genera aarchivo TXT
		var lines = rootData.lines.split('\n');
		var splitL = false;
		for (var i = 0; i < 1; i++) {
			var line = lines[i].split(';');
			if (line.length > 30) {
				splitL = true;
			}
		}
		if (splitL) {
			rootData.Lines = "";
			var centro = '\'' + rootData.Manual.idCentro + '\'';
			centro = rootData.Manual.idCentro + "";
			centro = centro.toUpperCase();
			for (var i = 0; i < lines.length; i++) {
				var txt = "";
				//var line = lines[i].split('\t');
				var line = lines[i].split(';');
				if (line[31] == centro || centro == "null" || centro == "NULL") {
					for (var j = 0; j < line.length - 1; j++) {
						if (line[j] == "NULL") {
							line[j] = "";
						}
						if (j == 27 || j == 28 || j == 26 || j == 34 || j == 35 || j == 36) {
							line[j] = Number(line[j]) + " ";
							if (line[j] == "NULL") {
								line[j] = "";
							}
							txt = txt + line[j] + "\t";
						}else {
							txt = txt + line[j] + "\t";
						}
					}
					rootData.archivoTXT = rootData.archivoTXT + txt + "\n";
				}
			}
		}else {
			rootData.archivoTXT = rootData.lines;
		}
		sc.endStep(); // Write_txtM_1
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: Write_txtM_1
// ----------------------------------------------------------------
GLOBAL.step( {
	Write_txtM_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'd1652de4-444f-40c8-b1c6-602b17183873');
		// Writes a text file.
		var file = rootData.filename;
		var txt = rootData.archivoTXT;
		ctx.fso.file.write(file, txt, e.file.encoding.UTF8);
		ctx.fso.file.write(rootData.filenameO, txt, e.file.encoding.UTF8);
		sc.endStep(); // Start_SAPLogon750
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: Start_SAPLogon750
// ----------------------------------------------------------------
GLOBAL.step( {
	Start_SAPLogon750: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '2bd3eae2-3ab4-4b9b-ace8-de7bd4a147f7');
		// Starts an application.
		SAPLogon750.start();
		sc.endStep(); // pWindowSAPLogon75_man
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: pWindowSAPLogon75_man
// ----------------------------------------------------------------
GLOBAL.step( {
	pWindowSAPLogon75_man: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'cbba684d-eb2b-439b-be9f-494dde72d1cc');
		// Wait until the Page loads
		SAPLogon750.pWindowSAPLogon75.wait(function (ev) {
			SAPLogon750.pWindowSAPLogon75.stQAS.click();
			SAPLogon750.pWindowSAPLogon75.btAccederAlSistema.click();
			sc.endStep(); // Declare_credentialM
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: Declare_credentialM
// ----------------------------------------------------------------
GLOBAL.step( {
	Declare_credentialM: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'a1e9a279-567d-439b-999c-dc45bd59a226');
		// Declares a credential

		ctx.cryptography.credential( {
			logonQAS: {
				comment: "logonQAS",
				server: true
			}
		});
		sc.endStep(); // Get_credentialM
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: Get_credentialM
// ----------------------------------------------------------------
GLOBAL.step( {
	Get_credentialM: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '267ceaff-c760-4e54-b83c-c1e91fef9180');
		// Retrieves credential login and password

		ctx.cryptography.credentials.logonQAS.get(function (code, label, credential) {
			if (code == e.error.OK) {
				// get values for credential
				rootData.sapgui.uname = credential.userName.get();
				rootData.sapgui.pass = credential.password.get();
				sc.endStep(); // pSAPLogin_management
				return ;
			}
		});
	}
});

// ----------------------------------------------------------------
//   Step: pSAPLogin_management
// ----------------------------------------------------------------
GLOBAL.step( {
	pSAPLogin_management: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '01b3d13f-2e57-4776-99d6-d003a57c0433');
		// Wait until the Page loads
		SAPLogon750.pSAPLogin.wait(function (ev) {
			SAPLogon750.pSAPLogin.edMandante.set("300");
			SAPLogon750.pSAPLogin.edUsuarios.set(rootData.sapgui.uname, true);
			SAPLogon750.pSAPLogin.oClvAcc.set(rootData.sapgui.pass, true);
			SAPLogon750.pSAPLogin.edIdioma.set("ES");
			SAPLogon750.pSAPLogin.keyStroke(e.SAPScripting.key._Enter_);
			sc.endStep(); // pSAPEasyAccess_manage
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: pSAPEasyAccess_manage
// ----------------------------------------------------------------
GLOBAL.step( {
	pSAPEasyAccess_manage: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '7bc73761-1972-4ac9-9062-20cc64c6744c');
		// Wait until the Page loads
		SAPLogon750.pSAPEasyAccess.wait(function (ev) {
			SAPLogon750.pSAPEasyAccess.oGuiOkCodeField.set("YSD_0001");
			SAPLogon750.pSAPEasyAccess.keyStroke(e.SAPScripting.key._Enter_);
			sc.endStep(); // Disable_step_timeout
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: Disable_step_timeout
// ----------------------------------------------------------------
GLOBAL.step( {
	Disable_step_timeout: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '68f0b1f6-b9d2-446a-acfc-c7d06281fd17');
		// Used to disable step timeout.
		st.disableTimeout();
		sc.endStep(); // pVentasYFacturasMas_m
		return ;
	}
});

// ----------------------------------------------------------------
//   Step: pVentasYFacturasMas_m
// ----------------------------------------------------------------
GLOBAL.step( {
	pVentasYFacturasMas_m: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'cc3be661-3dc3-4b8d-83a0-09b325ff94e4');
		// Wait until the Page loads
		SAPLogon750.pVentasYFacturasMas.wait(function (ev) {
			SAPLogon750.pVentasYFacturasMas.oSoloCarga.set(rootData.Manual.soloCarga);
			SAPLogon750.pVentasYFacturasMas.oVentaPorLínea.set("X");
			SAPLogon750.pVentasYFacturasMas.edFichero.set(rootData.filename);
			SAPLogon750.pVentasYFacturasMas.btEjecutar.click();
			sc.endStep(); // pPosDocumVisualiza_ma
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: pPosDocumVisualiza_ma
// ----------------------------------------------------------------
GLOBAL.step( {
	pPosDocumVisualiza_ma: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '734888b8-5a11-41f7-973e-efcb4016c673');
		// Wait until the Page loads
		SAPLogon750.pPosDocumVisualiza.wait(function (ev) {
			SAPLogon750.pPosDocumVisualiza.btAceptar.click();
			sc.endStep(); // pVentasYFacturasMas_m_1
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: pVentasYFacturasMas_m_1
// ----------------------------------------------------------------
GLOBAL.step( {
	pVentasYFacturasMas_m_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', '5c0bc4e5-441a-441b-a364-5edf2361719b');
		// Wait until the Page loads
		SAPLogon750.pVentasYFacturasMas.wait(function (ev) {
			SAPLogon750.pVentasYFacturasMas.btIFinalizar.click();
			sc.endStep(); // pSAPEasyAccess_manage_1
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: pSAPEasyAccess_manage_1
// ----------------------------------------------------------------
GLOBAL.step( {
	pSAPEasyAccess_manage_1: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'd0c040dc-fa29-43d0-8f8b-3e70bbdd5403');
		// Wait until the Page loads
		SAPLogon750.pSAPEasyAccess.wait(function (ev) {
			SAPLogon750.pSAPEasyAccess.btIFinalizar.click();
			sc.endStep(); // pSalirDelSistema_mana
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: pSalirDelSistema_mana
// ----------------------------------------------------------------
GLOBAL.step( {
	pSalirDelSistema_mana: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'd6efbcbb-7b7d-47fd-98be-f77c0d42cfda');
		// Wait until the Page loads
		SAPLogon750.pSalirDelSistema.wait(function (ev) {
			SAPLogon750.pSalirDelSistema.btSí.click();
			sc.endStep(); // end Scenario
			return ;
		});
	}
});

// ----------------------------------------------------------------
//   Step: DeleteFileMM
// ----------------------------------------------------------------
GLOBAL.step( {
	deleteFileMM: function (ev, sc, st) {
		var rootData = sc.data;
		ctx.workflow('cargaSAP_Manual', 'ffff62d6-03af-462d-84d8-7bd8845d5835');
		// Leer archivo generado
		var file = rootData.filename;
		ctx.fso.file.remove(file);
		sc.endStep(); // end
		return ;
	}
});
